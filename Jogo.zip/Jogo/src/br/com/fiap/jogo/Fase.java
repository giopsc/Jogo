package br.com.fiap.jogo;

public interface Fase {
	
	public void carregar(ElementoVisual elemento);
	
}