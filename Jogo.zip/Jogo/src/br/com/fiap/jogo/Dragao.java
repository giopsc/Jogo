package br.com.fiap.jogo;

public class Dragao extends Npc {

	public Dragao(int x, int y) {
		super(x, y);
	}
}
