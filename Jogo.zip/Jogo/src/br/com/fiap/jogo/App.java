package br.com.fiap.jogo;

public class App {

	public static void main(String[] args) {
		var mago = new Mago();
		
		mago.ganharExperiencia(10);
		
		//gio.receberCura(10);
		//gio.receberDano(10);
		//System.out.println(gio.getXp());
		
		
	}

}
