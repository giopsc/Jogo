package br.com.fiap.jogo;

public class Guerreiro extends Jogador {
	
	public Guerreiro() {
		super();
	}

	@Override
	public void mover(int x, int y) {
	}
}
