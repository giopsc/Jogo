package br.com.fiap.jogo;

public interface ElementoVisual {
	
	public void mover(int x, int y);
	
}